﻿namespace pIMC
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.labelPeso = new System.Windows.Forms.Label();
            this.labelAltura = new System.Windows.Forms.Label();
            this.labelIMC = new System.Windows.Forms.Label();
            this.maskedPeso = new System.Windows.Forms.MaskedTextBox();
            this.maskedAltura = new System.Windows.Forms.MaskedTextBox();
            this.maskedIMC = new System.Windows.Forms.MaskedTextBox();
            this.buttonLimpar = new System.Windows.Forms.Button();
            this.buttonCalcular = new System.Windows.Forms.Button();
            this.buttonSair = new System.Windows.Forms.Button();
            this.erroPeso = new System.Windows.Forms.ErrorProvider(this.components);
            this.erroAltura = new System.Windows.Forms.ErrorProvider(this.components);
            this.textResultado = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.erroPeso)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.erroAltura)).BeginInit();
            this.SuspendLayout();
            // 
            // labelPeso
            // 
            this.labelPeso.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPeso.Location = new System.Drawing.Point(27, 28);
            this.labelPeso.Name = "labelPeso";
            this.labelPeso.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.labelPeso.Size = new System.Drawing.Size(146, 23);
            this.labelPeso.TabIndex = 0;
            this.labelPeso.Text = "Peso Atual";
            this.labelPeso.Click += new System.EventHandler(this.Label1_Click);
            // 
            // labelAltura
            // 
            this.labelAltura.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAltura.Location = new System.Drawing.Point(27, 80);
            this.labelAltura.Name = "labelAltura";
            this.labelAltura.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.labelAltura.Size = new System.Drawing.Size(146, 26);
            this.labelAltura.TabIndex = 0;
            this.labelAltura.Text = "Altura";
            this.labelAltura.Click += new System.EventHandler(this.Label1_Click);
            // 
            // labelIMC
            // 
            this.labelIMC.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelIMC.Location = new System.Drawing.Point(27, 135);
            this.labelIMC.Name = "labelIMC";
            this.labelIMC.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.labelIMC.Size = new System.Drawing.Size(146, 26);
            this.labelIMC.TabIndex = 0;
            this.labelIMC.Text = "IMC";
            this.labelIMC.Click += new System.EventHandler(this.Label1_Click);
            // 
            // maskedPeso
            // 
            this.maskedPeso.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedPeso.Location = new System.Drawing.Point(179, 25);
            this.maskedPeso.Mask = "900.00";
            this.maskedPeso.Name = "maskedPeso";
            this.maskedPeso.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.maskedPeso.Size = new System.Drawing.Size(148, 26);
            this.maskedPeso.TabIndex = 1;
            this.maskedPeso.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.maskedPeso.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.MaskedPeso_MaskInputRejected);
            this.maskedPeso.Click += new System.EventHandler(this.MaskedPeso_Click);
            // 
            // maskedAltura
            // 
            this.maskedAltura.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedAltura.Location = new System.Drawing.Point(179, 80);
            this.maskedAltura.Mask = "0.00";
            this.maskedAltura.Name = "maskedAltura";
            this.maskedAltura.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.maskedAltura.Size = new System.Drawing.Size(148, 26);
            this.maskedAltura.TabIndex = 1;
            this.maskedAltura.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.maskedAltura.Click += new System.EventHandler(this.MaskedAltura_Click);
            // 
            // maskedIMC
            // 
            this.maskedIMC.Enabled = false;
            this.maskedIMC.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedIMC.Location = new System.Drawing.Point(179, 135);
            this.maskedIMC.Name = "maskedIMC";
            this.maskedIMC.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.maskedIMC.Size = new System.Drawing.Size(148, 26);
            this.maskedIMC.TabIndex = 1;
            this.maskedIMC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // buttonLimpar
            // 
            this.buttonLimpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonLimpar.Location = new System.Drawing.Point(179, 201);
            this.buttonLimpar.Name = "buttonLimpar";
            this.buttonLimpar.Size = new System.Drawing.Size(130, 49);
            this.buttonLimpar.TabIndex = 2;
            this.buttonLimpar.Text = "Limpar";
            this.buttonLimpar.UseVisualStyleBackColor = true;
            this.buttonLimpar.Click += new System.EventHandler(this.ButtonLimpar_Click);
            // 
            // buttonCalcular
            // 
            this.buttonCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCalcular.Location = new System.Drawing.Point(27, 201);
            this.buttonCalcular.Name = "buttonCalcular";
            this.buttonCalcular.Size = new System.Drawing.Size(130, 49);
            this.buttonCalcular.TabIndex = 2;
            this.buttonCalcular.Text = "Calcular";
            this.buttonCalcular.UseVisualStyleBackColor = true;
            this.buttonCalcular.Click += new System.EventHandler(this.ButtonCalcular_Click);
            // 
            // buttonSair
            // 
            this.buttonSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSair.Location = new System.Drawing.Point(328, 201);
            this.buttonSair.Name = "buttonSair";
            this.buttonSair.Size = new System.Drawing.Size(130, 49);
            this.buttonSair.TabIndex = 2;
            this.buttonSair.Text = "Sair";
            this.buttonSair.UseVisualStyleBackColor = true;
            this.buttonSair.Click += new System.EventHandler(this.ButtonSair_Click);
            // 
            // erroPeso
            // 
            this.erroPeso.ContainerControl = this;
            // 
            // erroAltura
            // 
            this.erroAltura.ContainerControl = this;
            // 
            // textResultado
            // 
            this.textResultado.Enabled = false;
            this.textResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textResultado.Location = new System.Drawing.Point(179, 340);
            this.textResultado.Name = "textResultado";
            this.textResultado.Size = new System.Drawing.Size(279, 26);
            this.textResultado.TabIndex = 3;
            this.textResultado.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(27, 343);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label1.Size = new System.Drawing.Size(146, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "Resultado";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label1.Click += new System.EventHandler(this.Label1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textResultado);
            this.Controls.Add(this.buttonSair);
            this.Controls.Add(this.buttonCalcular);
            this.Controls.Add(this.buttonLimpar);
            this.Controls.Add(this.maskedIMC);
            this.Controls.Add(this.maskedAltura);
            this.Controls.Add(this.maskedPeso);
            this.Controls.Add(this.labelIMC);
            this.Controls.Add(this.labelAltura);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelPeso);
            this.Name = "Form1";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.erroPeso)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.erroAltura)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelPeso;
        private System.Windows.Forms.Label labelAltura;
        private System.Windows.Forms.Label labelIMC;
        private System.Windows.Forms.MaskedTextBox maskedPeso;
        private System.Windows.Forms.MaskedTextBox maskedAltura;
        private System.Windows.Forms.MaskedTextBox maskedIMC;
        private System.Windows.Forms.Button buttonLimpar;
        private System.Windows.Forms.Button buttonCalcular;
        private System.Windows.Forms.Button buttonSair;
        private System.Windows.Forms.ErrorProvider erroPeso;
        private System.Windows.Forms.ErrorProvider erroAltura;
        private System.Windows.Forms.TextBox textResultado;
        private System.Windows.Forms.Label label1;
    }
}

