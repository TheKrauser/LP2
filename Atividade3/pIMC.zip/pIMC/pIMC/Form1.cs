﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pIMC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void MaskedPeso_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void ButtonLimpar_Click(object sender, EventArgs e)
        {
            maskedAltura.Clear();
            maskedPeso.Clear();
            maskedIMC.Clear();
            textResultado.Clear();
        }

        private void ButtonSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void MaskedPeso_Click(object sender, EventArgs e)
        {
            maskedPeso.Select(0, 0);
        }

        private void MaskedAltura_Click(object sender, EventArgs e)
        {
            maskedAltura.Select(0, 0);
        }


        double peso, altura;
        private void ButtonCalcular_Click(object sender, EventArgs e)
        {
            double imc;

            if (!double.TryParse(maskedPeso.Text, out peso) || !double.TryParse(maskedAltura.Text, out altura))
            {
                if (altura <= 0)
                {
                    erroAltura.SetError(maskedAltura, "Valor Inválido! (Menor ou igual a 0)");
                }

                if (peso <= 0)
                {
                    erroPeso.SetError(maskedPeso, "Valor Inválido! (Menor ou igual a 0)");
                }

                return;
            }

            imc = peso / Math.Pow(altura, 2);
            imc = Math.Round(imc, 1);
            maskedIMC.Text = imc.ToString();

            erroAltura.SetError(maskedAltura, "");
            erroPeso.SetError(maskedPeso, "");

            if (imc < 18.5)
            {
                textResultado.Text = "Magreza";
            }
            else if (imc < 24.9)
            {
                textResultado.Text = "Normal";
            }
            else if (imc < 29.9)
            {
                textResultado.Text = "Sobrepeso";
            }
            else if (imc < 39.9)
            {
                textResultado.Text = "Obesidade";
            }
            else
            {
                textResultado.Text = "Obesidade Grave";
            }
        }
    }
}
