﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        double raio;
        double altura;

        string erro;
        bool hasError = false;

        private void ButtonCalcular_Click(object sender, EventArgs e)
        {
            erro = "";

            if ((!double.TryParse(txtRaio.Text, out raio) || raio <= 0) || (!double.TryParse(txtAltura.Text, out altura) || altura <= 0))
            {
                erro += "DADOS INVÁLIDOS!\n\nAmbos os valores não podem ser\n\n\nNEGATIVOS\nou\nMENORES QUE 0";
                hasError = true;
                //txtRaio.Focus();
            }
            else
            {
                hasError = false;
                raio = double.Parse(txtRaio.Text);
                altura = double.Parse(txtAltura.Text);
            }

            if (!hasError)
            {
                var volume = Math.PI * Math.Pow(raio, 2) * altura;

                txtVolume.Text = $"{volume.ToString("N2")}";
            }
            else
            {
                MessageBox.Show(erro);
            }
        }

        private void TxtRaio_Validated(object sender, EventArgs e)
        {
            /*if (!double.TryParse(txtRaio.Text, out raio))
            {
                MessageBox.Show("Raio Inválido!");
                //txtRaio.Focus();
            }
            else
            {
                if (raio <= 0)
                {
                    MessageBox.Show("Raio não pode ser MENOR OU IGUAL A 0");
                    txtRaio.Focus();
                }
            }*/
        }

        private void TxtAltura_Validated(object sender, EventArgs e)
        {
            /*if (!double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("Raio Inválido!");
                txtAltura.Focus();
            }
            else
            {
                if (altura <= 0)
                {
                    MessageBox.Show("Altura não pode ser MENOR OU IGUAL A 0");
                    txtAltura.Focus();
                }
            }*/
        }

        private void ButtonFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
