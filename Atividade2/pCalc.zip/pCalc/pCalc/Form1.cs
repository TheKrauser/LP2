﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pCalc
{
    public partial class Form1 : Form
    {
        double n1, n2, resultado;


        public Form1()
        {
            InitializeComponent();
        }

        private void ButtonSoma_OnClick(object sender, EventArgs e)
        {
            textResultado.Text = (n1 + n2).ToString();
        }

        private void TextN1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(textN1.Text, out n1))
            {
                MessageBox.Show("Número Inválido!");
                textN1.Focus();
                textN1.Clear();
            }
        }

        private void TextN2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(textN2.Text, out n2))
            {
                MessageBox.Show("Número Inválido!");
                textN2.Focus();
                textN2.Clear();
            }
        }

        private void ButtonSub_OnClick(object sender, EventArgs e)
        {
            textResultado.Text = (n1 - n2).ToString();
        }

        private void ButtonMult_OnClick(object sender, EventArgs e)
        {
            textResultado.Text = (n1 * n2).ToString();
        }

        private void ButtonDiv_OnClick(object sender, EventArgs e)
        {
            if (n2 == 0)
            {
                MessageBox.Show("Não é possível realizar DIVISÃO POR ZERO!", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textN2.Focus();
            }
            else
            {
                textResultado.Text = (n1 / n2).ToString();
            }

        }

        private void ButtonLimpar_Click(object sender, EventArgs e)
        {
            textN1.Clear();
            textN2.Clear();
            textResultado.Clear();

            textN1.Focus();
            resultado = 0;

            textResultado.Clear();
        }

        private void TextN1_KeyPress(object sender, KeyPressEventArgs e)
        {
            TAB(e);
        }

        private void TextN2_KeyPress(object sender, KeyPressEventArgs e)
        {
            TAB(e);
        }

        private void ButtonSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja realmente sair?", "Sair", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        private void TAB(KeyPressEventArgs press)
        {
            if (press.KeyChar == (char)13)
            {
                SendKeys.Send("{TAB}");
                press.Handled = true;
            }
        }
    }
}
