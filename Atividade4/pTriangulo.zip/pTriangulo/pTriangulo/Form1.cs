﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pTriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        double valorA, valorB, valorC;
        bool bA = false, bB = false, bC = false;

        private void buttonCalcular_Click(object sender, EventArgs e)
        {
            if (!bA || !bB || !bC)
            {
                textResultado.Text = "Valores Inválidos";
            }
            else
            {
                if ((Math.Abs(valorB - valorC) < valorA && valorA < valorB + valorC) &&
                    (Math.Abs(valorA - valorC) < valorB && valorB < valorA + valorC) &&
                    (Math.Abs(valorA - valorB) < valorC && valorC < valorA + valorB))
                {
                    if (valorA == valorB && valorB == valorC && valorC == valorA)
                    {
                        textResultado.Text = "Triângulo Equilátero";
                    }
                    else if (valorA != valorB && valorB != valorC && valorC != valorA)
                    {
                        textResultado.Text = "Triângulo Escaleno";
                    }
                    else
                    {
                        textResultado.Text = "Triângulo Isósceles";
                    }
                }
                else
                {
                    textResultado.Text = "Não é um Triangulo!";
                }
            }
        }

        private void buttonLimpar_Click(object sender, EventArgs e)
        {
            textA.Clear();
            erroA.SetError(textA, "");
            textB.Clear();
            erroB.SetError(textB, "");
            textC.Clear();
            erroC.SetError(textC, "");
            textResultado.Clear();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void buttonSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void textA_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(textA.Text, out valorA))
            {
                erroA.SetError(textA, "Número Inválido!");
                bA = false;
            }
            else
            {
                erroA.SetError(textA, "");
                bA = true;
            }
        }

        private void textB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(textB.Text, out valorB))
            {
                erroB.SetError(textB, "Número Inválido!");
                bB = false;
            }
            else
            {
                erroB.SetError(textB, "");
                bB = true;
            }
        }

        private void textC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(textC.Text, out valorC))
            {
                erroC.SetError(textC, "Número Inválido!");
                bC = false;
            }
            else
            {
                erroC.SetError(textC, "");
                bC = true;
            }
        }
    }
}
