﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace pMatrizes
{
    public partial class FormEx5 : Form
    {
        public FormEx5()
        {
            InitializeComponent();
        }

        private void ReceberNomes()
        {
            List<string> nomes = new List<string>();

            string s = "";
            for(int i=0; i<2; i++)
            {
                s = Interaction.InputBox($"Digite um nome completo para a posição [{i + 1}]");
                nomes.Add(s);
            }

            foreach(string st in nomes)
            {
                s = st.Replace(" ", "");
                listNomes.Items.Add($"o nome: {st} tem {s.Length} caracteres");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ReceberNomes();
        }

        private void FormEx5_Load(object sender, EventArgs e)
        {

        }
    }
}
