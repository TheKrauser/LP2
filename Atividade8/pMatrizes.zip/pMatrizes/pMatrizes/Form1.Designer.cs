﻿namespace pMatrizes
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonEx1 = new System.Windows.Forms.Button();
            this.buttonEx2 = new System.Windows.Forms.Button();
            this.buttonEx3 = new System.Windows.Forms.Button();
            this.buttonEx4 = new System.Windows.Forms.Button();
            this.buttonEx5 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonEx1
            // 
            this.buttonEx1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonEx1.Location = new System.Drawing.Point(104, 34);
            this.buttonEx1.Name = "buttonEx1";
            this.buttonEx1.Size = new System.Drawing.Size(138, 59);
            this.buttonEx1.TabIndex = 0;
            this.buttonEx1.Text = "Exercicio 1";
            this.buttonEx1.UseVisualStyleBackColor = true;
            this.buttonEx1.Click += new System.EventHandler(this.ButtonEx1_Click);
            // 
            // buttonEx2
            // 
            this.buttonEx2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonEx2.Location = new System.Drawing.Point(298, 34);
            this.buttonEx2.Name = "buttonEx2";
            this.buttonEx2.Size = new System.Drawing.Size(138, 59);
            this.buttonEx2.TabIndex = 0;
            this.buttonEx2.Text = "Exercicio 2";
            this.buttonEx2.UseVisualStyleBackColor = true;
            this.buttonEx2.Click += new System.EventHandler(this.ButtonEx2_Click);
            // 
            // buttonEx3
            // 
            this.buttonEx3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonEx3.Location = new System.Drawing.Point(495, 34);
            this.buttonEx3.Name = "buttonEx3";
            this.buttonEx3.Size = new System.Drawing.Size(138, 59);
            this.buttonEx3.TabIndex = 0;
            this.buttonEx3.Text = "Exercicio 3";
            this.buttonEx3.UseVisualStyleBackColor = true;
            this.buttonEx3.Click += new System.EventHandler(this.buttonEx3_Click);
            // 
            // buttonEx4
            // 
            this.buttonEx4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonEx4.Location = new System.Drawing.Point(203, 150);
            this.buttonEx4.Name = "buttonEx4";
            this.buttonEx4.Size = new System.Drawing.Size(138, 59);
            this.buttonEx4.TabIndex = 0;
            this.buttonEx4.Text = "Exercicio 4";
            this.buttonEx4.UseVisualStyleBackColor = true;
            this.buttonEx4.Click += new System.EventHandler(this.buttonEx4_Click);
            // 
            // buttonEx5
            // 
            this.buttonEx5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonEx5.Location = new System.Drawing.Point(402, 150);
            this.buttonEx5.Name = "buttonEx5";
            this.buttonEx5.Size = new System.Drawing.Size(138, 59);
            this.buttonEx5.TabIndex = 0;
            this.buttonEx5.Text = "Exercicio 5";
            this.buttonEx5.UseVisualStyleBackColor = true;
            this.buttonEx5.Click += new System.EventHandler(this.buttonEx5_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonEx5);
            this.Controls.Add(this.buttonEx4);
            this.Controls.Add(this.buttonEx3);
            this.Controls.Add(this.buttonEx2);
            this.Controls.Add(this.buttonEx1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonEx1;
        private System.Windows.Forms.Button buttonEx2;
        private System.Windows.Forms.Button buttonEx3;
        private System.Windows.Forms.Button buttonEx4;
        private System.Windows.Forms.Button buttonEx5;
    }
}

