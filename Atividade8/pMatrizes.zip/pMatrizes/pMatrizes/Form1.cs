﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace pMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void ButtonEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            string saida = "";

            for (int i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox($"Digite um número [Posição: {i + 1}]");
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número Inválido! (não é um número inteiro)");
                    i--;
                }
                else
                {
                    saida = vetor[i] + " " + saida;
                }
            }

            //MessageBox.Show(saida);

            Array.Reverse(vetor);
            auxiliar = "";

            foreach (int i in vetor)
            {
                auxiliar += $"{i} ";
            }

            MessageBox.Show($"Vetor reverso: {auxiliar}");

        }

        private void ButtonEx2_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            double media = 0;
            string nota = "";
            string imprimir = "";

            for (int i = 0; i < notas.GetLength(0); i++)
            {
                imprimir += $"Aluno {i + 1}: Média: ";
                for (int j = 0; j < notas.GetLength(1); j++)
                {
                    nota = Interaction.InputBox($"Digite a nota {j + 1} do Aluno {i + 1}");
                    if(nota.Length == 0)
                    {
                        return;
                    }
                    else if (!double.TryParse(nota, out notas[i, j]) || notas[i,j] < 0 || notas[i,j] > 10)
                    {
                        MessageBox.Show($"Nota Inválida!\nDigite Novamente.");
                        j--;
                    }
                    else
                    {
                        media += notas[i, j];
                    }
                }

                media /= 3;
                imprimir += $"{media.ToString("N2")}\n";
                media = 0;
            }

            MessageBox.Show(imprimir);
        }

        private void buttonEx3_Click(object sender, EventArgs e)
        {
            string[] Alunos = {"Viviane", "André", "Hélio", "Denise", "Junior",
            "Leonardo", "Jose", "Nelma", "Tobby"};

            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
            }
            MessageBox.Show(Total.ToString());
        }

        private void buttonEx4_Click(object sender, EventArgs e)
        {
            ArrayList nomes = new ArrayList {"Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais" };
            nomes.Remove("Otávio");

            string t = "";
            foreach(string s in nomes)
            {
                t += s + "\n";
            }

            MessageBox.Show($"{t}");
        }

        private void buttonEx5_Click(object sender, EventArgs e)
        {
            FormEx5 formEx5 = new FormEx5();
            //formEx5.MdiParent = this;
            formEx5.WindowState = FormWindowState.Normal;
            formEx5.Show();
        }
    }
}
