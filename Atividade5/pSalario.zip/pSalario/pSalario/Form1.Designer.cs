﻿namespace pSalario
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelFuncionario = new System.Windows.Forms.Label();
            this.textFuncionario = new System.Windows.Forms.TextBox();
            this.labelSalarioBruto = new System.Windows.Forms.Label();
            this.labelNumeroFilhos = new System.Windows.Forms.Label();
            this.maskedSalarioBruto = new System.Windows.Forms.MaskedTextBox();
            this.numericFilhos = new System.Windows.Forms.NumericUpDown();
            this.buttonVerificaDesconto = new System.Windows.Forms.Button();
            this.labelAliquotaINSS = new System.Windows.Forms.Label();
            this.labelDescontoINSS = new System.Windows.Forms.Label();
            this.textDescontoINSS = new System.Windows.Forms.TextBox();
            this.labelAliquotaIRPF = new System.Windows.Forms.Label();
            this.labelDescontoIRPF = new System.Windows.Forms.Label();
            this.textAliquotaIRPF = new System.Windows.Forms.TextBox();
            this.textDescontoIRPF = new System.Windows.Forms.TextBox();
            this.labelSalarioFamilia = new System.Windows.Forms.Label();
            this.textSalarioFamilia = new System.Windows.Forms.TextBox();
            this.labelSalarioLiquido = new System.Windows.Forms.Label();
            this.textSalarioLiquido = new System.Windows.Forms.TextBox();
            this.textAliquotaINSS = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericFilhos)).BeginInit();
            this.SuspendLayout();
            // 
            // labelFuncionario
            // 
            this.labelFuncionario.AutoSize = true;
            this.labelFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFuncionario.Location = new System.Drawing.Point(12, 30);
            this.labelFuncionario.Name = "labelFuncionario";
            this.labelFuncionario.Size = new System.Drawing.Size(154, 20);
            this.labelFuncionario.TabIndex = 0;
            this.labelFuncionario.Text = "Nome Funcionário";
            // 
            // textFuncionario
            // 
            this.textFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textFuncionario.Location = new System.Drawing.Point(172, 27);
            this.textFuncionario.Name = "textFuncionario";
            this.textFuncionario.Size = new System.Drawing.Size(475, 26);
            this.textFuncionario.TabIndex = 1;
            this.textFuncionario.TextChanged += new System.EventHandler(this.textFuncionario_TextChanged);
            // 
            // labelSalarioBruto
            // 
            this.labelSalarioBruto.AutoSize = true;
            this.labelSalarioBruto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSalarioBruto.Location = new System.Drawing.Point(12, 80);
            this.labelSalarioBruto.Name = "labelSalarioBruto";
            this.labelSalarioBruto.Size = new System.Drawing.Size(114, 20);
            this.labelSalarioBruto.TabIndex = 0;
            this.labelSalarioBruto.Text = "Salário Bruto";
            // 
            // labelNumeroFilhos
            // 
            this.labelNumeroFilhos.AutoSize = true;
            this.labelNumeroFilhos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNumeroFilhos.Location = new System.Drawing.Point(12, 130);
            this.labelNumeroFilhos.Name = "labelNumeroFilhos";
            this.labelNumeroFilhos.Size = new System.Drawing.Size(149, 20);
            this.labelNumeroFilhos.TabIndex = 0;
            this.labelNumeroFilhos.Text = "Número de Filhos";
            // 
            // maskedSalarioBruto
            // 
            this.maskedSalarioBruto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedSalarioBruto.Location = new System.Drawing.Point(172, 77);
            this.maskedSalarioBruto.Mask = "00999.99";
            this.maskedSalarioBruto.Name = "maskedSalarioBruto";
            this.maskedSalarioBruto.Size = new System.Drawing.Size(256, 26);
            this.maskedSalarioBruto.TabIndex = 2;
            this.maskedSalarioBruto.Validated += new System.EventHandler(this.MaskedSalarioBruto_Validated);
            // 
            // numericFilhos
            // 
            this.numericFilhos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericFilhos.Location = new System.Drawing.Point(172, 128);
            this.numericFilhos.Name = "numericFilhos";
            this.numericFilhos.Size = new System.Drawing.Size(120, 26);
            this.numericFilhos.TabIndex = 3;
            // 
            // buttonVerificaDesconto
            // 
            this.buttonVerificaDesconto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonVerificaDesconto.Location = new System.Drawing.Point(73, 200);
            this.buttonVerificaDesconto.Name = "buttonVerificaDesconto";
            this.buttonVerificaDesconto.Size = new System.Drawing.Size(219, 38);
            this.buttonVerificaDesconto.TabIndex = 4;
            this.buttonVerificaDesconto.Text = "Verifica Desconto";
            this.buttonVerificaDesconto.UseVisualStyleBackColor = true;
            this.buttonVerificaDesconto.Click += new System.EventHandler(this.ButtonVerificaDesconto_Click);
            // 
            // labelAliquotaINSS
            // 
            this.labelAliquotaINSS.AutoSize = true;
            this.labelAliquotaINSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAliquotaINSS.Location = new System.Drawing.Point(12, 285);
            this.labelAliquotaINSS.Name = "labelAliquotaINSS";
            this.labelAliquotaINSS.Size = new System.Drawing.Size(122, 20);
            this.labelAliquotaINSS.TabIndex = 0;
            this.labelAliquotaINSS.Text = "Aliquota INSS";
            // 
            // labelDescontoINSS
            // 
            this.labelDescontoINSS.AutoSize = true;
            this.labelDescontoINSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDescontoINSS.Location = new System.Drawing.Point(342, 285);
            this.labelDescontoINSS.Name = "labelDescontoINSS";
            this.labelDescontoINSS.Size = new System.Drawing.Size(133, 20);
            this.labelDescontoINSS.TabIndex = 0;
            this.labelDescontoINSS.Text = "Desconto INSS";
            // 
            // textDescontoINSS
            // 
            this.textDescontoINSS.Enabled = false;
            this.textDescontoINSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textDescontoINSS.Location = new System.Drawing.Point(502, 282);
            this.textDescontoINSS.Name = "textDescontoINSS";
            this.textDescontoINSS.Size = new System.Drawing.Size(145, 26);
            this.textDescontoINSS.TabIndex = 1;
            // 
            // labelAliquotaIRPF
            // 
            this.labelAliquotaIRPF.AutoSize = true;
            this.labelAliquotaIRPF.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAliquotaIRPF.Location = new System.Drawing.Point(12, 335);
            this.labelAliquotaIRPF.Name = "labelAliquotaIRPF";
            this.labelAliquotaIRPF.Size = new System.Drawing.Size(121, 20);
            this.labelAliquotaIRPF.TabIndex = 0;
            this.labelAliquotaIRPF.Text = "Aliquota IRPF";
            // 
            // labelDescontoIRPF
            // 
            this.labelDescontoIRPF.AutoSize = true;
            this.labelDescontoIRPF.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDescontoIRPF.Location = new System.Drawing.Point(342, 335);
            this.labelDescontoIRPF.Name = "labelDescontoIRPF";
            this.labelDescontoIRPF.Size = new System.Drawing.Size(132, 20);
            this.labelDescontoIRPF.TabIndex = 0;
            this.labelDescontoIRPF.Text = "Desconto IRPF";
            // 
            // textAliquotaIRPF
            // 
            this.textAliquotaIRPF.Enabled = false;
            this.textAliquotaIRPF.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textAliquotaIRPF.Location = new System.Drawing.Point(172, 332);
            this.textAliquotaIRPF.Name = "textAliquotaIRPF";
            this.textAliquotaIRPF.Size = new System.Drawing.Size(145, 26);
            this.textAliquotaIRPF.TabIndex = 1;
            // 
            // textDescontoIRPF
            // 
            this.textDescontoIRPF.Enabled = false;
            this.textDescontoIRPF.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textDescontoIRPF.Location = new System.Drawing.Point(502, 332);
            this.textDescontoIRPF.Name = "textDescontoIRPF";
            this.textDescontoIRPF.Size = new System.Drawing.Size(145, 26);
            this.textDescontoIRPF.TabIndex = 1;
            // 
            // labelSalarioFamilia
            // 
            this.labelSalarioFamilia.AutoSize = true;
            this.labelSalarioFamilia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSalarioFamilia.Location = new System.Drawing.Point(12, 385);
            this.labelSalarioFamilia.Name = "labelSalarioFamilia";
            this.labelSalarioFamilia.Size = new System.Drawing.Size(127, 20);
            this.labelSalarioFamilia.TabIndex = 0;
            this.labelSalarioFamilia.Text = "Salario Familia";
            // 
            // textSalarioFamilia
            // 
            this.textSalarioFamilia.Enabled = false;
            this.textSalarioFamilia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textSalarioFamilia.Location = new System.Drawing.Point(172, 382);
            this.textSalarioFamilia.Name = "textSalarioFamilia";
            this.textSalarioFamilia.Size = new System.Drawing.Size(145, 26);
            this.textSalarioFamilia.TabIndex = 1;
            // 
            // labelSalarioLiquido
            // 
            this.labelSalarioLiquido.AutoSize = true;
            this.labelSalarioLiquido.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSalarioLiquido.Location = new System.Drawing.Point(12, 435);
            this.labelSalarioLiquido.Name = "labelSalarioLiquido";
            this.labelSalarioLiquido.Size = new System.Drawing.Size(128, 20);
            this.labelSalarioLiquido.TabIndex = 0;
            this.labelSalarioLiquido.Text = "Salario Liquido";
            // 
            // textSalarioLiquido
            // 
            this.textSalarioLiquido.Enabled = false;
            this.textSalarioLiquido.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textSalarioLiquido.Location = new System.Drawing.Point(172, 432);
            this.textSalarioLiquido.Name = "textSalarioLiquido";
            this.textSalarioLiquido.Size = new System.Drawing.Size(145, 26);
            this.textSalarioLiquido.TabIndex = 1;
            // 
            // textAliquotaINSS
            // 
            this.textAliquotaINSS.Enabled = false;
            this.textAliquotaINSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textAliquotaINSS.Location = new System.Drawing.Point(172, 282);
            this.textAliquotaINSS.Name = "textAliquotaINSS";
            this.textAliquotaINSS.Size = new System.Drawing.Size(145, 26);
            this.textAliquotaINSS.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(659, 501);
            this.Controls.Add(this.buttonVerificaDesconto);
            this.Controls.Add(this.numericFilhos);
            this.Controls.Add(this.maskedSalarioBruto);
            this.Controls.Add(this.textDescontoIRPF);
            this.Controls.Add(this.textSalarioLiquido);
            this.Controls.Add(this.textSalarioFamilia);
            this.Controls.Add(this.textAliquotaIRPF);
            this.Controls.Add(this.textDescontoINSS);
            this.Controls.Add(this.textAliquotaINSS);
            this.Controls.Add(this.labelDescontoIRPF);
            this.Controls.Add(this.labelSalarioLiquido);
            this.Controls.Add(this.textFuncionario);
            this.Controls.Add(this.labelSalarioFamilia);
            this.Controls.Add(this.labelDescontoINSS);
            this.Controls.Add(this.labelAliquotaIRPF);
            this.Controls.Add(this.labelNumeroFilhos);
            this.Controls.Add(this.labelAliquotaINSS);
            this.Controls.Add(this.labelSalarioBruto);
            this.Controls.Add(this.labelFuncionario);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericFilhos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelFuncionario;
        private System.Windows.Forms.TextBox textFuncionario;
        private System.Windows.Forms.Label labelSalarioBruto;
        private System.Windows.Forms.Label labelNumeroFilhos;
        private System.Windows.Forms.MaskedTextBox maskedSalarioBruto;
        private System.Windows.Forms.NumericUpDown numericFilhos;
        private System.Windows.Forms.Button buttonVerificaDesconto;
        private System.Windows.Forms.Label labelAliquotaINSS;
        private System.Windows.Forms.Label labelDescontoINSS;
        private System.Windows.Forms.TextBox textDescontoINSS;
        private System.Windows.Forms.Label labelAliquotaIRPF;
        private System.Windows.Forms.Label labelDescontoIRPF;
        private System.Windows.Forms.TextBox textAliquotaIRPF;
        private System.Windows.Forms.TextBox textDescontoIRPF;
        private System.Windows.Forms.Label labelSalarioFamilia;
        private System.Windows.Forms.TextBox textSalarioFamilia;
        private System.Windows.Forms.Label labelSalarioLiquido;
        private System.Windows.Forms.TextBox textSalarioLiquido;
        private System.Windows.Forms.TextBox textAliquotaINSS;
    }
}

