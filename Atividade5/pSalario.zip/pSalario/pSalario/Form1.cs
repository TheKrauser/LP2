﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pSalario
{
    public partial class Form1 : Form
    {
        bool valido;
        double salarioBruto;
        public Form1()
        {
            InitializeComponent();
        }

        private void ButtonVerificaDesconto_Click(object sender, EventArgs e)
        {
            double aliquotaINSS;
            double aliquotaIRPF;
            double porFilho;

            double valorINSS = 0;
            double valorIRPF = 0;
            double valorFilho = 0;

            double tetoINSS = 308.17;

            if (valido)
            {
                if (salarioBruto <= 800.47f)
                {
                    aliquotaINSS = 0.0765;
                    textAliquotaINSS.Text = (aliquotaINSS * 100).ToString("N2")+"%";
                }
                else if (salarioBruto <= 1050f)
                {
                    aliquotaINSS = 0.0865;
                    textAliquotaINSS.Text = (aliquotaINSS * 100).ToString("N2")+"%";
                }
                else if (salarioBruto <= 1400.77f)
                {
                    aliquotaINSS = 0.09;
                    textAliquotaINSS.Text = (aliquotaINSS * 100).ToString("N2")+"%";
                }
                else if (salarioBruto <= 2801.56f)
                {
                    aliquotaINSS = 0.11;
                    textAliquotaINSS.Text = (aliquotaINSS * 100).ToString("N2")+"%";
                }
                else
                {
                    aliquotaINSS = 1;
                    textAliquotaINSS.Text = "TETO";
                }

                if (aliquotaINSS != 1)
                {
                    valorINSS = aliquotaINSS * salarioBruto;
                    textDescontoINSS.Text = valorINSS.ToString("N2");
                }
                else
                {
                    valorINSS = 308.17;
                    textDescontoINSS.Text = tetoINSS.ToString("N2");
                }
            }

            if (valido)
            {
                if (salarioBruto <= 1257.12f)
                {
                    aliquotaIRPF = 1;
                    textAliquotaIRPF.Text = "ISENTO";
                }
                else if (salarioBruto <= 2512.08f)
                {
                    aliquotaIRPF = 0.15;
                    textAliquotaIRPF.Text = (aliquotaIRPF * 100).ToString("N2")+"%";
                }
                else
                {
                    aliquotaIRPF = 0.275;
                    textAliquotaIRPF.Text = (aliquotaIRPF * 100).ToString("N2")+"%";
                }

                if (aliquotaIRPF != 1)
                {
                    valorIRPF = aliquotaIRPF * salarioBruto;
                    textDescontoIRPF.Text = valorIRPF.ToString("N2");
                }
                else
                {
                    valorIRPF = 0;
                    textDescontoIRPF.Text = "0";
                }
            }

            if (valido)
            {
                if (salarioBruto <= 435.52)
                {
                    porFilho = 22.33;
                }
                else if (salarioBruto <= 654.61)
                {
                    porFilho = 15.74;
                }
                else
                {
                    porFilho = 0;
                }

                valorFilho = porFilho * (int)numericFilhos.Value;
                textSalarioFamilia.Text = valorFilho.ToString("N2");
            }

            if (valido)
            {
                textSalarioLiquido.Text = (salarioBruto - valorINSS - valorIRPF + valorFilho).ToString("N2");
            }
        }

        private void MaskedSalarioBruto_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(maskedSalarioBruto.Text, out salarioBruto))
            {
                MessageBox.Show("Salario Bruto Inválido!");
                valido = false;
            }
            else
            {
                valido = true;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textFuncionario_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
