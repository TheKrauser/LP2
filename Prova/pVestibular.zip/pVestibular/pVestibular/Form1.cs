﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace pVestibular
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void ButtonReceber_Click(object sender, EventArgs e)
        {
            double[,] valores = new double[5,4];
            double alunosCurso = 0;
            double totalCurso = 0;
            double somaTotal = 0;

            string alunos = "";
            string auxiliar = "";

            listBoxValores.Items.Clear();
            for (int i=0; i<5; i++)
            {
                totalCurso = 0;
                for (int j=0; j<4; j++)
                {
                    auxiliar = "";
                    alunos = Interaction.InputBox($"Insira o Total de Alunos do Curso {i+1}: ");
                    if (alunos.Length == 0)
                    {
                        return;
                    }
                    else if (!double.TryParse(alunos, out alunosCurso) || alunosCurso < 0)
                    {
                        MessageBox.Show("Valor Inválido!");
                        j--;
                    }
                    else
                    {
                        valores[i, j] = alunosCurso;
                        auxiliar += $"Total do curso {i+1} Ano {j+1}: {valores[i,j]}";
                        listBoxValores.Items.Add(auxiliar);
                        somaTotal += alunosCurso;
                        totalCurso += alunosCurso;
                    }
                }
                listBoxValores.Items.Add($">>Total Curso: {totalCurso}");
                listBoxValores.Items.Add("----------------------------------------------------");
            }
            listBoxValores.Items.Add($">>Total Geral: {somaTotal}");
        }

        private void ButtonLimpar_Click(object sender, EventArgs e)
        {
            listBoxValores.Items.Clear();
        }
    }
}
