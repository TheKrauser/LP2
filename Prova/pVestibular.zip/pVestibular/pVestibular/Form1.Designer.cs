﻿namespace pVestibular
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonReceber = new System.Windows.Forms.Button();
            this.buttonLimpar = new System.Windows.Forms.Button();
            this.listBoxValores = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // buttonReceber
            // 
            this.buttonReceber.Location = new System.Drawing.Point(152, 118);
            this.buttonReceber.Name = "buttonReceber";
            this.buttonReceber.Size = new System.Drawing.Size(198, 59);
            this.buttonReceber.TabIndex = 0;
            this.buttonReceber.Text = "ReceberDados";
            this.buttonReceber.UseVisualStyleBackColor = true;
            this.buttonReceber.Click += new System.EventHandler(this.ButtonReceber_Click);
            // 
            // buttonLimpar
            // 
            this.buttonLimpar.Location = new System.Drawing.Point(152, 242);
            this.buttonLimpar.Name = "buttonLimpar";
            this.buttonLimpar.Size = new System.Drawing.Size(198, 59);
            this.buttonLimpar.TabIndex = 0;
            this.buttonLimpar.Text = "Limpar";
            this.buttonLimpar.UseVisualStyleBackColor = true;
            this.buttonLimpar.Click += new System.EventHandler(this.ButtonLimpar_Click);
            // 
            // listBoxValores
            // 
            this.listBoxValores.FormattingEnabled = true;
            this.listBoxValores.Location = new System.Drawing.Point(419, 12);
            this.listBoxValores.Name = "listBoxValores";
            this.listBoxValores.Size = new System.Drawing.Size(270, 420);
            this.listBoxValores.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.listBoxValores);
            this.Controls.Add(this.buttonLimpar);
            this.Controls.Add(this.buttonReceber);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonReceber;
        private System.Windows.Forms.Button buttonLimpar;
        private System.Windows.Forms.ListBox listBoxValores;
    }
}

