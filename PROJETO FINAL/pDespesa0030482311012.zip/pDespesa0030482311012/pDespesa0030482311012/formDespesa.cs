﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pDespesa0030482311012
{
    public partial class formDespesa : Form
    {
        private BindingSource bnDespesa = new BindingSource();
        private bool boolInclusao = false;
        private DataSet dsDespesa = new DataSet();
        private DataSet dsTipo = new DataSet();

        public formDespesa()
        {
            InitializeComponent();
        }

        private void TabPage1_Click(object sender, EventArgs e)
        {

        }

        private void LabelID_Click(object sender, EventArgs e)
        {

        }

        private void FormDespesa_Load(object sender, EventArgs e)
        {
            buttonSalvar.Enabled = false;
            buttonCancelar.Enabled = false;

            try
            {
                Despesa Con = new Despesa();
                dsDespesa.Tables.Add(Con.Listar());
                bnDespesa.DataSource = dsDespesa.Tables["Despesa"];
                dataGridDespesa.DataSource = bnDespesa;
                bindingDespesa.BindingSource = bnDespesa;


                textID.DataBindings.Add("TEXT", bnDespesa, "IDDESPESA");
                maskedValor.DataBindings.Add("TEXT", bnDespesa, "VALORDESPESA");
                dateData.DataBindings.Add("TEXT", bnDespesa, "DATADESPESA");
                textObs.DataBindings.Add("TEXT", bnDespesa, "OBSDESPESA");



                // carrega dados do tipo
                Tipo ObjT = new Tipo();
                dsTipo.Tables.Add(ObjT.Listar());
                comboTipo.DataSource = dsTipo.Tables["Tipo"];
                //CAMPO QUE SERÁ MOSTRADO PARA O USUÁRIO
                comboTipo.DisplayMember = "descricaotipo";
                //CAMPO QUE É A CHAVE DA TABELA TIPO E QUE LIGA COM A TABELA DE DESPESA
                comboTipo.ValueMember = "idtipo";
                //linkar combox do tipo
                comboTipo.DataBindings.Add("SelectedValue",
                    bnDespesa, "TIPO_IDTIPO"); // AJUSTAR DROPDOWNSTYLE PARA DropDownList PARA NAO DEIXAR DIGITAR
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void ButtonNovo_Click(object sender, EventArgs e)
        {
            if (tabDespesa.SelectedIndex == 0)
            {
                tabDespesa.SelectTab(1);
            }

            bnDespesa.AddNew();



            maskedValor.Enabled = true;
            dateData.Enabled = true;
            textObs.Enabled = true;
            comboTipo.Enabled = true;



            comboTipo.SelectedIndex = 0;

            buttonNovo.Enabled = false;
            buttonAlterar.Enabled = false;
            buttonExcluir.Enabled = false;
            buttonSalvar.Enabled = true;
            buttonCancelar.Enabled = true;



            boolInclusao = true;
        }

        private void ButtonSalvar_Click(object sender, EventArgs e)
        {
            double valor;

            // validar os dados
            if (!Double.TryParse(maskedValor.Text, out valor))
            {
                MessageBox.Show("Valor inválido!");
            }
            else
            {
                Despesa RegDesp = new Despesa();



                RegDesp.despesaValor = valor;
                RegDesp.despesaData = dateData.Value;
                RegDesp.despesaObs = textObs.Text;
                RegDesp.Tipo_tipoID = Convert.ToInt32(comboTipo.SelectedValue.ToString());

                if (boolInclusao)
                {
                    if (RegDesp.Incluir() > 0)
                    {
                        MessageBox.Show("Despesa adicionado com sucesso!");



                        maskedValor.Enabled = false;
                        dateData.Enabled = false;
                        textObs.Enabled = false;
                        comboTipo.Enabled = false;



                        buttonNovo.Enabled = true;
                        buttonAlterar.Enabled = true;
                        buttonExcluir.Enabled = true;
                        buttonAlterar.Enabled = false;
                        buttonCancelar.Enabled = false;

                        boolInclusao = false;

                        // recarrega o grid
                        dsDespesa.Tables.Clear();
                        dsDespesa.Tables.Add(RegDesp.Listar());
                        bnDespesa.DataSource = dsDespesa.Tables["Despesa"];
                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar despesa!");
                    }
                }
                else
                {
                    RegDesp.despesaID = Convert.ToInt32(textID.Text);



                    if (RegDesp.Alterar() > 0)
                    {
                        MessageBox.Show("Despesa alterada com sucesso!", "SUCESSO");



                        maskedValor.Enabled = false;
                        dateData.Enabled = false;
                        textObs.Enabled = false;
                        comboTipo.Enabled = false;



                        buttonNovo.Enabled = true;
                        buttonAlterar.Enabled = true;
                        buttonExcluir.Enabled = true;
                        buttonSalvar.Enabled = false;
                        buttonCancelar.Enabled = false;



                        // recarrega o grid
                        dsDespesa.Tables.Clear();
                        dsDespesa.Tables.Add(RegDesp.Listar());
                        bnDespesa.DataSource = dsDespesa.Tables["Despesa"];
                    }
                    else
                    {
                        MessageBox.Show("Erro ao alterar despesa!");
                    }
                }
            }
        }

        private void ButtonAlterar_Click(object sender, EventArgs e)
        {
            if (tabDespesa.SelectedIndex == 0)
            {
                tabDespesa.SelectTab(1);
            }



            maskedValor.Enabled = true;
            dateData.Enabled = true;
            textObs.Enabled = true;
            comboTipo.Enabled = true;



            buttonNovo.Enabled = false;
            buttonAlterar.Enabled = false;
            buttonExcluir.Enabled = false;
            buttonSalvar.Enabled = true;
            buttonCancelar.Enabled = true;



            boolInclusao = false;

        }

        private void ButtonExcluir_Click(object sender, EventArgs e)
        {
            if (tabDespesa.SelectedIndex == 0)
            {
                tabDespesa.SelectTab(1);
            }
            if (MessageBox.Show("Confirma exclusão?", "Yes or No",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Despesa RegDesp = new Despesa();
                RegDesp.despesaID = Convert.ToInt32(textID.Text);



                if (RegDesp.Excluir() > 0)
                {
                    MessageBox.Show("Despesa excluída com sucesso!", "SUCESSO");



                    // recarrega o grid
                    dsDespesa.Tables.Clear();
                    dsDespesa.Tables.Add(RegDesp.Listar());
                    bnDespesa.DataSource = dsDespesa.Tables["Despesa"];
                }
                else
                {
                    MessageBox.Show("Erro ao excluir contato!", "ERRO");
                }
            }
        }

        private void ButtonCancelar_Click(object sender, EventArgs e)
        {
            bnDespesa.CancelEdit();



            maskedValor.Enabled = false;
            dateData.Enabled = false;
            textObs.Enabled = false;
            comboTipo.Enabled = false;



            buttonNovo.Enabled = true;
            buttonAlterar.Enabled = true;
            buttonExcluir.Enabled = true;
            buttonSalvar.Enabled = false;
            buttonCancelar.Enabled = false;



            boolInclusao = false;
        }

        private void ButtonSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
