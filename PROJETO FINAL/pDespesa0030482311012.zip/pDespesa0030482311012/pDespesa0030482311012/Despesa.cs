﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace pDespesa0030482311012
{
    class Despesa
    {
        public int despesaID { get; set; }
        public double despesaValor { get; set; }
        public DateTime despesaData { get; set; }
        public string despesaObs { get; set; }
        public int Tipo_tipoID { get; set; }

        public DataTable Listar()
        {
            SqlDataAdapter daDespesa;

            DataTable dtDespesa = new DataTable();

            try
            {
                daDespesa = new SqlDataAdapter("SELECT * FROM DESPESA", formPrincipal.conexao);
                daDespesa.Fill(dtDespesa);
                daDespesa.FillSchema(dtDespesa, SchemaType.Source);
            }
            catch (Exception)
            {
                throw;
            }
            return dtDespesa;
        }

        public int Incluir() // INCLUSAO
        {
            int retorno = 0;
            try
            {
                SqlCommand mycommand;

                mycommand = new SqlCommand("INSERT INTO DESPESA VALUES (@despesavalor,@despesadata,@despesaobs," +
                "@tipo_tipoid)", formPrincipal.conexao);

                mycommand.Parameters.Add(new SqlParameter("@despesavalor", SqlDbType.Decimal));
                mycommand.Parameters.Add(new SqlParameter("@despesadata", SqlDbType.DateTime));
                mycommand.Parameters.Add(new SqlParameter("@despesaobs", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@tipo_tipoid", SqlDbType.Int));

                mycommand.Parameters["@despesavalor"].Value = despesaValor;
                mycommand.Parameters["@despesadata"].Value = despesaData;
                mycommand.Parameters["@despesaobs"].Value = despesaObs;
                mycommand.Parameters["@tipo_tipoid"].Value = Tipo_tipoID;

                retorno = mycommand.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            return retorno;
        }

        public int Alterar() // alteração
        {
            int retorno = 0;

            try
            {
                SqlCommand mycommand;

                mycommand = new SqlCommand("UPDATE DESPESA SET VALORDESPESA=@despesavalor,DATADESPESA=@despesadata," +
                "OBSDESPESA=@despesaobs,TIPO_IDTIPO =@tipo_tipoid WHERE IDDESPESA = @despesaid", formPrincipal.conexao);

                mycommand.Parameters.Add(new SqlParameter("@despesaid", SqlDbType.Int));
                mycommand.Parameters.Add(new SqlParameter("@despesavalor", SqlDbType.Decimal));
                mycommand.Parameters.Add(new SqlParameter("@despesadata", SqlDbType.DateTime));
                mycommand.Parameters.Add(new SqlParameter("@despesaobs", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@tipo_tipoid", SqlDbType.Int));

                mycommand.Parameters["@despesaid"].Value = despesaID;
                mycommand.Parameters["@despesavalor"].Value = despesaValor;
                mycommand.Parameters["@despesadata"].Value = despesaData;
                mycommand.Parameters["@despesaobs"].Value = despesaObs;
                mycommand.Parameters["@tipo_tipoid"].Value = Tipo_tipoID;

                retorno = mycommand.ExecuteNonQuery();

            }
            catch (Exception)
            {
                throw;
            }

            return retorno;
        }

        public int Excluir() // EXCLUSÃO
        {
            int nReg = 0;

            try
            {
                SqlCommand mycommand;

                mycommand = new SqlCommand("DELETE FROM DESPESA WHERE IDDESPESA=@despesaid", formPrincipal.conexao);

                mycommand.Parameters.Add(new SqlParameter("@despesaid", SqlDbType.Int));
                mycommand.Parameters["@despesaid"].Value = despesaID;

                nReg = mycommand.ExecuteNonQuery();
            }

            catch (Exception)
            {
                throw;
            }

            return nReg;
        }
    }
}
