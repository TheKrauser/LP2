﻿namespace pDespesa0030482311012
{
    partial class formDespesa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formDespesa));
            this.bindingDespesa = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.buttonNovo = new System.Windows.Forms.ToolStripButton();
            this.buttonSalvar = new System.Windows.Forms.ToolStripButton();
            this.buttonAlterar = new System.Windows.Forms.ToolStripButton();
            this.buttonExcluir = new System.Windows.Forms.ToolStripButton();
            this.buttonCancelar = new System.Windows.Forms.ToolStripButton();
            this.buttonSair = new System.Windows.Forms.ToolStripButton();
            this.tabDespesa = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dataGridDespesa = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.comboTipo = new System.Windows.Forms.ComboBox();
            this.textObs = new System.Windows.Forms.TextBox();
            this.dateData = new System.Windows.Forms.DateTimePicker();
            this.maskedValor = new System.Windows.Forms.MaskedTextBox();
            this.textID = new System.Windows.Forms.TextBox();
            this.labelTipo = new System.Windows.Forms.Label();
            this.labelObs = new System.Windows.Forms.Label();
            this.labelData = new System.Windows.Forms.Label();
            this.labelValor = new System.Windows.Forms.Label();
            this.labelID = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.bindingDespesa)).BeginInit();
            this.bindingDespesa.SuspendLayout();
            this.tabDespesa.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridDespesa)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // bindingDespesa
            // 
            this.bindingDespesa.AddNewItem = null;
            this.bindingDespesa.CountItem = this.bindingNavigatorCountItem;
            this.bindingDespesa.DeleteItem = null;
            this.bindingDespesa.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.buttonNovo,
            this.buttonSalvar,
            this.buttonAlterar,
            this.buttonExcluir,
            this.buttonCancelar,
            this.buttonSair});
            this.bindingDespesa.Location = new System.Drawing.Point(0, 0);
            this.bindingDespesa.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.bindingDespesa.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.bindingDespesa.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.bindingDespesa.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.bindingDespesa.Name = "bindingDespesa";
            this.bindingDespesa.PositionItem = this.bindingNavigatorPositionItem;
            this.bindingDespesa.Size = new System.Drawing.Size(800, 25);
            this.bindingDespesa.TabIndex = 0;
            this.bindingDespesa.Text = "bindingNavigator1";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // buttonNovo
            // 
            this.buttonNovo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.buttonNovo.Image = ((System.Drawing.Image)(resources.GetObject("buttonNovo.Image")));
            this.buttonNovo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.buttonNovo.Name = "buttonNovo";
            this.buttonNovo.Size = new System.Drawing.Size(23, 22);
            this.buttonNovo.Text = "toolStripButton1";
            this.buttonNovo.Click += new System.EventHandler(this.ButtonNovo_Click);
            // 
            // buttonSalvar
            // 
            this.buttonSalvar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.buttonSalvar.Image = ((System.Drawing.Image)(resources.GetObject("buttonSalvar.Image")));
            this.buttonSalvar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.buttonSalvar.Name = "buttonSalvar";
            this.buttonSalvar.Size = new System.Drawing.Size(23, 22);
            this.buttonSalvar.Text = "toolStripButton2";
            this.buttonSalvar.Click += new System.EventHandler(this.ButtonSalvar_Click);
            // 
            // buttonAlterar
            // 
            this.buttonAlterar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.buttonAlterar.Image = ((System.Drawing.Image)(resources.GetObject("buttonAlterar.Image")));
            this.buttonAlterar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.buttonAlterar.Name = "buttonAlterar";
            this.buttonAlterar.Size = new System.Drawing.Size(23, 22);
            this.buttonAlterar.Text = "toolStripButton3";
            this.buttonAlterar.Click += new System.EventHandler(this.ButtonAlterar_Click);
            // 
            // buttonExcluir
            // 
            this.buttonExcluir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.buttonExcluir.Image = ((System.Drawing.Image)(resources.GetObject("buttonExcluir.Image")));
            this.buttonExcluir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.buttonExcluir.Name = "buttonExcluir";
            this.buttonExcluir.Size = new System.Drawing.Size(23, 22);
            this.buttonExcluir.Text = "toolStripButton4";
            this.buttonExcluir.Click += new System.EventHandler(this.ButtonExcluir_Click);
            // 
            // buttonCancelar
            // 
            this.buttonCancelar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.buttonCancelar.Image = ((System.Drawing.Image)(resources.GetObject("buttonCancelar.Image")));
            this.buttonCancelar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.buttonCancelar.Name = "buttonCancelar";
            this.buttonCancelar.Size = new System.Drawing.Size(23, 22);
            this.buttonCancelar.Text = "toolStripButton5";
            this.buttonCancelar.Click += new System.EventHandler(this.ButtonCancelar_Click);
            // 
            // buttonSair
            // 
            this.buttonSair.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.buttonSair.Image = ((System.Drawing.Image)(resources.GetObject("buttonSair.Image")));
            this.buttonSair.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.buttonSair.Name = "buttonSair";
            this.buttonSair.Size = new System.Drawing.Size(23, 22);
            this.buttonSair.Text = "toolStripButton6";
            this.buttonSair.Click += new System.EventHandler(this.ButtonSair_Click);
            // 
            // tabDespesa
            // 
            this.tabDespesa.Controls.Add(this.tabPage1);
            this.tabDespesa.Controls.Add(this.tabPage2);
            this.tabDespesa.Location = new System.Drawing.Point(12, 99);
            this.tabDespesa.Name = "tabDespesa";
            this.tabDespesa.SelectedIndex = 0;
            this.tabDespesa.Size = new System.Drawing.Size(776, 273);
            this.tabDespesa.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dataGridDespesa);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(768, 247);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Dados";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.TabPage1_Click);
            // 
            // dataGridDespesa
            // 
            this.dataGridDespesa.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridDespesa.Location = new System.Drawing.Point(0, 0);
            this.dataGridDespesa.Name = "dataGridDespesa";
            this.dataGridDespesa.Size = new System.Drawing.Size(772, 247);
            this.dataGridDespesa.TabIndex = 2;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.pictureBox1);
            this.tabPage2.Controls.Add(this.comboTipo);
            this.tabPage2.Controls.Add(this.textObs);
            this.tabPage2.Controls.Add(this.dateData);
            this.tabPage2.Controls.Add(this.maskedValor);
            this.tabPage2.Controls.Add(this.textID);
            this.tabPage2.Controls.Add(this.labelTipo);
            this.tabPage2.Controls.Add(this.labelObs);
            this.tabPage2.Controls.Add(this.labelData);
            this.tabPage2.Controls.Add(this.labelValor);
            this.tabPage2.Controls.Add(this.labelID);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(768, 247);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Detalhes";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // comboTipo
            // 
            this.comboTipo.Enabled = false;
            this.comboTipo.FormattingEnabled = true;
            this.comboTipo.Location = new System.Drawing.Point(108, 159);
            this.comboTipo.Name = "comboTipo";
            this.comboTipo.Size = new System.Drawing.Size(157, 21);
            this.comboTipo.TabIndex = 5;
            // 
            // textObs
            // 
            this.textObs.Enabled = false;
            this.textObs.Location = new System.Drawing.Point(108, 133);
            this.textObs.Name = "textObs";
            this.textObs.Size = new System.Drawing.Size(313, 20);
            this.textObs.TabIndex = 4;
            // 
            // dateData
            // 
            this.dateData.CustomFormat = "dd/MM/yyyy";
            this.dateData.Enabled = false;
            this.dateData.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateData.Location = new System.Drawing.Point(108, 105);
            this.dateData.Name = "dateData";
            this.dateData.Size = new System.Drawing.Size(128, 20);
            this.dateData.TabIndex = 3;
            // 
            // maskedValor
            // 
            this.maskedValor.Enabled = false;
            this.maskedValor.Location = new System.Drawing.Point(108, 79);
            this.maskedValor.Name = "maskedValor";
            this.maskedValor.Size = new System.Drawing.Size(144, 20);
            this.maskedValor.TabIndex = 2;
            // 
            // textID
            // 
            this.textID.Enabled = false;
            this.textID.Location = new System.Drawing.Point(108, 53);
            this.textID.Name = "textID";
            this.textID.Size = new System.Drawing.Size(111, 20);
            this.textID.TabIndex = 1;
            // 
            // labelTipo
            // 
            this.labelTipo.AutoSize = true;
            this.labelTipo.Location = new System.Drawing.Point(19, 162);
            this.labelTipo.Name = "labelTipo";
            this.labelTipo.Size = new System.Drawing.Size(28, 13);
            this.labelTipo.TabIndex = 0;
            this.labelTipo.Text = "Tipo";
            this.labelTipo.Click += new System.EventHandler(this.LabelID_Click);
            // 
            // labelObs
            // 
            this.labelObs.AutoSize = true;
            this.labelObs.Location = new System.Drawing.Point(19, 136);
            this.labelObs.Name = "labelObs";
            this.labelObs.Size = new System.Drawing.Size(65, 13);
            this.labelObs.TabIndex = 0;
            this.labelObs.Text = "Observação";
            this.labelObs.Click += new System.EventHandler(this.LabelID_Click);
            // 
            // labelData
            // 
            this.labelData.AutoSize = true;
            this.labelData.Location = new System.Drawing.Point(19, 109);
            this.labelData.Name = "labelData";
            this.labelData.Size = new System.Drawing.Size(30, 13);
            this.labelData.TabIndex = 0;
            this.labelData.Text = "Data";
            this.labelData.Click += new System.EventHandler(this.LabelID_Click);
            // 
            // labelValor
            // 
            this.labelValor.AutoSize = true;
            this.labelValor.Location = new System.Drawing.Point(19, 85);
            this.labelValor.Name = "labelValor";
            this.labelValor.Size = new System.Drawing.Size(31, 13);
            this.labelValor.TabIndex = 0;
            this.labelValor.Text = "Valor";
            this.labelValor.Click += new System.EventHandler(this.LabelID_Click);
            // 
            // labelID
            // 
            this.labelID.AutoSize = true;
            this.labelID.Location = new System.Drawing.Point(19, 60);
            this.labelID.Name = "labelID";
            this.labelID.Size = new System.Drawing.Size(18, 13);
            this.labelID.TabIndex = 0;
            this.labelID.Text = "ID";
            this.labelID.Click += new System.EventHandler(this.LabelID_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(498, 23);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(226, 204);
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // formDespesa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 521);
            this.Controls.Add(this.tabDespesa);
            this.Controls.Add(this.bindingDespesa);
            this.Name = "formDespesa";
            this.Text = "formDespesa";
            this.Load += new System.EventHandler(this.FormDespesa_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bindingDespesa)).EndInit();
            this.bindingDespesa.ResumeLayout(false);
            this.bindingDespesa.PerformLayout();
            this.tabDespesa.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridDespesa)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingNavigator bindingDespesa;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton buttonNovo;
        private System.Windows.Forms.ToolStripButton buttonSalvar;
        private System.Windows.Forms.ToolStripButton buttonAlterar;
        private System.Windows.Forms.ToolStripButton buttonExcluir;
        private System.Windows.Forms.ToolStripButton buttonCancelar;
        private System.Windows.Forms.ToolStripButton buttonSair;
        private System.Windows.Forms.TabControl tabDespesa;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dataGridDespesa;
        private System.Windows.Forms.Label labelID;
        private System.Windows.Forms.ComboBox comboTipo;
        private System.Windows.Forms.TextBox textObs;
        private System.Windows.Forms.DateTimePicker dateData;
        private System.Windows.Forms.MaskedTextBox maskedValor;
        private System.Windows.Forms.TextBox textID;
        private System.Windows.Forms.Label labelTipo;
        private System.Windows.Forms.Label labelObs;
        private System.Windows.Forms.Label labelData;
        private System.Windows.Forms.Label labelValor;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}