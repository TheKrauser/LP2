﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace pDespesa0030482311012
{
    public partial class formPrincipal : Form
    {
        public static SqlConnection conexao;

        public formPrincipal()
        {
            InitializeComponent();
        }

        private void formPrincipal_Load(object sender, EventArgs e)
        {
            try
            {
                // aqui a conexão vai depende da sua máquina da escola ou particular
                conexao = new SqlConnection("Data Source=Apolo;Initial Catalog=LP2;User ID=BD2311012;Password=DenilceLP22023");
                conexao.Open();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Erro de banco de dados =/" + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Outros Erros =/" + ex.Message);
            }
        }

        private void CadastroDespesasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<formDespesa>().Count() > 0)
            {
                Application.OpenForms["formDespesa"].BringToFront();
            }
            else
            {
                formDespesa formDesp = new formDespesa();
                formDesp.MdiParent = this;
                formDesp.WindowState = FormWindowState.Maximized;
                formDesp.Show();
            }
        }

        private void SobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<formSobre>().Count() > 0)
            {
                Application.OpenForms["formSobre"].BringToFront();
            }
            else
            {
                formSobre formSob= new formSobre();
                formSob.MdiParent = this;
                formSob.WindowState = FormWindowState.Maximized;
                formSob.Show();
            }
        }

        private void SairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
