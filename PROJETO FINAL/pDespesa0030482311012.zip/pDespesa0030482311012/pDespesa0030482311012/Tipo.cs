﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace pDespesa0030482311012
{
    class Tipo
    {
        private int tipoID;
        private string tipoDescricao;

        public int TipoID
        {
            get 
            {
                return tipoID;
            }
            set 
            {
                tipoID = value;
            }
        }

        public string TipoDescricao
        {
            get
            {
                return tipoDescricao;
            }
            set
            {
                tipoDescricao = value;
            }
        }

        public DataTable Listar()
        {
            SqlDataAdapter daTipo;

            DataTable dtTipo = new DataTable();

            try
            {
                daTipo = new SqlDataAdapter("SELECT * FROM TIPO", formPrincipal.conexao);
                daTipo.Fill(dtTipo);
                daTipo.FillSchema(dtTipo, SchemaType.Source);
            }
            catch
            {
                throw;
            }

            return dtTipo;
        }
    }
}
