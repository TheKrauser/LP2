﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            int cont = 0;
            for(int i=0; i<rchtxtFrase.Text.Length; i++)
            {
                if (char.IsNumber(rchtxtFrase.Text[i]))
                {
                    cont++;
                }
            }

            MessageBox.Show($"Quantidade de Numeros: {cont}");
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            int cont = 0;

            foreach(char c in rchtxtFrase.Text)
            {
                if (char.IsLetter(c))
                {
                    cont++;
                }
            }

            MessageBox.Show($"Quantidade de Letras: {cont}");
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            int cont = 0;

            while(cont < rchtxtFrase.Text.Length)
            {
                if (char.IsWhiteSpace(rchtxtFrase.Text[cont]))
                {
                    break;
                }
                cont++;
            }

            MessageBox.Show($"Posicao do Primeiro Espaco: {cont+1}");
        }
    }
}
